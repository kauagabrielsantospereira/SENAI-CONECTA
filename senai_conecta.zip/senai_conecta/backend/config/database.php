<php
$host = "localhost";
$dbname = "senai_conecta";
$username = "root";
$password = "";
?>